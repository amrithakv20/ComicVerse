from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import Comic


class FoundationTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user("owner", password="StrongPass123!")
        self.other = User.objects.create_user("other", password="StrongPass123!")
        self.draft = Comic.objects.create(owner=self.owner, title="Secret", status=Comic.DRAFT)

    def test_home_loads(self):
        self.assertEqual(self.client.get(reverse("home")).status_code, 200)

    def test_profile_created_on_signup(self):
        self.assertTrue(hasattr(self.owner, "profile"))

    def test_dashboard_requires_login(self):
        resp = self.client.get(reverse("dashboard"))
        self.assertEqual(resp.status_code, 302)

    def test_draft_hidden_from_others(self):
        self.client.login(username="other", password="StrongPass123!")
        self.assertEqual(self.client.get(self.draft.get_absolute_url()).status_code, 404)

    def test_draft_visible_to_owner(self):
        self.client.login(username="owner", password="StrongPass123!")
        self.assertEqual(self.client.get(self.draft.get_absolute_url()).status_code, 200)

    def test_register_creates_user(self):
        resp = self.client.post(reverse("register"), {
            "username": "newbie", "email": "n@example.com",
            "password1": "StrongPass123!", "password2": "StrongPass123!",
        })
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(User.objects.filter(username="newbie").exists())
