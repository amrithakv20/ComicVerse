from django.contrib import admin

from .models import Bookmark, Chapter, Character, Comic, Like, Panel

for model in (Comic, Character, Chapter, Panel, Like, Bookmark):
    admin.site.register(model)
