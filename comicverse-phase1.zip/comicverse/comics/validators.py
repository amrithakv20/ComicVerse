from django.conf import settings
from django.core.exceptions import ValidationError
from PIL import Image

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


def validate_image(f):
    """Check size and real image format (not just the file extension)."""
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    if f.size > max_bytes:
        raise ValidationError(f"Image must be smaller than {settings.MAX_UPLOAD_SIZE_MB} MB.")
    try:
        img = Image.open(f)
        img.verify()
        fmt = img.format
    except Exception:
        raise ValidationError("Upload a valid image file.")
    finally:
        f.seek(0)
    if fmt not in ALLOWED_FORMATS:
        raise ValidationError("Only JPEG, PNG or WEBP images are allowed.")
