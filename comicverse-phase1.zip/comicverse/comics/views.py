from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Count
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render

from .forms import ComicForm
from .models import Chapter, Comic, Panel


def home(request):
    published = Comic.objects.filter(status=Comic.PUBLISHED)
    genre_counts = {g["genre"]: g["n"] for g in published.values("genre").annotate(n=Count("id"))}
    genres = [
        {"key": key, "label": label, "count": genre_counts.get(key, 0)}
        for key, label in Comic.GENRE_CHOICES
    ]
    context = {
        "featured": published.select_related("owner").annotate(like_total=Count("likes"))[:6],
        "genres": genres,
        "stats": {
            "comics": published.count(),
            "creators": User.objects.filter(comics__status=Comic.PUBLISHED).distinct().count(),
            "chapters": Chapter.objects.filter(comic__status=Comic.PUBLISHED).count(),
            "panels": Panel.objects.filter(chapter__comic__status=Comic.PUBLISHED).count(),
        },
    }
    return render(request, "home.html", context)


@login_required
def dashboard(request):
    mine = request.user.comics.all()
    context = {
        "total": mine.count(),
        "published": mine.filter(status=Comic.PUBLISHED).count(),
        "drafts": mine.filter(status=Comic.DRAFT).count(),
        "recent": mine[:6],
    }
    return render(request, "comics/dashboard.html", context)


@login_required
def comic_list(request):
    return render(request, "comics/library.html", {"comics": request.user.comics.all()})


@login_required
def comic_create(request):
    form = ComicForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        comic = form.save(commit=False)
        comic.owner = request.user
        comic.save()
        messages.success(request, "Comic created as a draft.")
        return redirect(comic)
    return render(request, "comics/comic_form.html", {"form": form})


def comic_detail(request, pk):
    comic = get_object_or_404(Comic.objects.select_related("owner"), pk=pk)
    # Drafts are private: only the owner can see them.
    if not comic.is_published and comic.owner != request.user:
        raise Http404
    return render(request, "comics/comic_detail.html", {"comic": comic, "is_owner": comic.owner == request.user})
