from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("library/", views.comic_list, name="comic_list"),
    path("comics/new/", views.comic_create, name="comic_create"),
    path("comics/<int:pk>/", views.comic_detail, name="comic_detail"),
]
