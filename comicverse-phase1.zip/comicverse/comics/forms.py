from django import forms

from .models import Comic


class ComicForm(forms.ModelForm):
    class Meta:
        model = Comic
        fields = ("title", "description", "genre", "cover_image")
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}
