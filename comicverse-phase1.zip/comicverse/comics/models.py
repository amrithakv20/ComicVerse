from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse

from .validators import validate_image


class Comic(models.Model):
    DRAFT, PUBLISHED = "draft", "published"
    STATUS_CHOICES = [(DRAFT, "Draft"), (PUBLISHED, "Published")]
    GENRE_CHOICES = [
        ("fantasy", "Fantasy"), ("romance", "Romance"), ("action", "Action"),
        ("mystery", "Mystery"), ("comedy", "Comedy"), ("horror", "Horror"),
        ("adventure", "Adventure"),
    ]

    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="comics")
    title = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    genre = models.CharField(max_length=20, choices=GENRE_CHOICES, default="fantasy")
    style = models.CharField(max_length=30, default="Anime/Manga")
    story_idea = models.TextField(blank=True)
    mood = models.CharField(max_length=100, blank=True)
    cover_image = models.ImageField(upload_to="covers/", blank=True, validators=[validate_image])
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=DRAFT)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("comic_detail", args=[self.pk])

    @property
    def is_published(self):
        return self.status == self.PUBLISHED


class Character(models.Model):
    comic = models.ForeignKey(Comic, on_delete=models.CASCADE, related_name="characters")
    name = models.CharField(max_length=80)
    age = models.CharField(max_length=20, blank=True)
    appearance = models.TextField(blank=True)
    personality = models.TextField(blank=True)
    backstory = models.TextField(blank=True)
    reference_image = models.ImageField(upload_to="characters/", blank=True, validators=[validate_image])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.comic.title})"


class Chapter(models.Model):
    comic = models.ForeignKey(Comic, on_delete=models.CASCADE, related_name="chapters")
    number = models.PositiveIntegerField(default=1)
    title = models.CharField(max_length=150)
    summary = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["number"]
        unique_together = ("comic", "number")

    def __str__(self):
        return f"Ch. {self.number}: {self.title}"


class Panel(models.Model):
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name="panels")
    order = models.PositiveIntegerField(default=1)
    scene_description = models.TextField(blank=True)
    dialogue = models.TextField(blank=True)
    narration = models.TextField(blank=True)
    background = models.TextField(blank=True)
    camera_angle = models.CharField(max_length=120, blank=True)
    bubbles = models.JSONField(default=list, blank=True)
    image = models.ImageField(upload_to="panels/", blank=True, validators=[validate_image])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"Panel {self.order} of {self.chapter}"


class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="likes")
    comic = models.ForeignKey(Comic, on_delete=models.CASCADE, related_name="likes")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "comic")


class Bookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookmarks")
    comic = models.ForeignKey(Comic, on_delete=models.CASCADE, related_name="bookmarks")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "comic")
        ordering = ["-created_at"]
