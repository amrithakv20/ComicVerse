from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from comics.models import Chapter, Character, Comic, Panel

DEMO = [
    ("Moonlight Courier", "fantasy", "A night-time delivery girl carries wishes between rival spirit realms.",
     "Mika", "Silver-haired courier with a lantern satchel."),
    ("Shadow Over Hinode High", "mystery", "A quiet student notices classmates forgetting one person entirely.",
     "Ren", "Sharp-eyed transfer student with a notebook always in hand."),
    ("Ramen Dojo Rivals", "comedy", "Two cooks battle for the title of Tokyo's loudest noodle master.",
     "Daichi", "Tall, headband-wearing chef with endless confidence."),
]


class Command(BaseCommand):
    help = "Create a demo user and sample comics."

    def handle(self, *args, **options):
        user, created = User.objects.get_or_create(username="demo_creator", defaults={"email": "demo@example.com"})
        if created:
            user.set_password("DemoPass12345")
            user.save()
            user.profile.bio = "Demo creator account for ComicVerse sample data."
            user.profile.save()
        for title, genre, desc, hero, look in DEMO:
            comic, new = Comic.objects.get_or_create(
                owner=user, title=title,
                defaults={"genre": genre, "description": desc, "status": Comic.PUBLISHED},
            )
            if not new:
                continue
            Character.objects.create(comic=comic, name=hero, appearance=look, personality="Determined and curious.")
            chapter = Chapter.objects.create(comic=comic, number=1, title="Chapter One")
            for i in range(1, 4):
                Panel.objects.create(
                    chapter=chapter, order=i,
                    scene_description=f"Opening scene {i} featuring {hero}.",
                    dialogue=f"{hero}: This is only the beginning.", camera_angle="Wide establishing shot",
                )
        self.stdout.write(self.style.SUCCESS("Demo data ready. Login: demo_creator / DemoPass12345"))
