# ComicVerse

> Your imagination. Your universe. Your comic.

AI-powered anime/manga webtoon creator built with Django, SQLite and the Gemini API.

**Status:** Phase 1 (foundation): project structure, landing page, authentication, profiles, database models, dashboard, demo data.

## Tech stack
Python, Django, SQLite, Pillow, python-dotenv, google-genai, HTML5, CSS3, vanilla JavaScript, Bootstrap 5.

## Setup (macOS)
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then edit .env
python manage.py migrate
python manage.py seed_demo  # optional sample data
python manage.py createsuperuser
python manage.py runserver
```
Open http://127.0.0.1:8000

## Tests
```bash
python manage.py test
```

## Roadmap
- Phase 2: AI Story Studio and Gemini service (`ai_engine`)
- Phase 3: Character Studio and Comic Editor
- Phase 4: Webtoon reader, likes, bookmarks
- Phase 5: Explore, search, publishing, README screenshots

## Screenshots
_Add after running the app._
