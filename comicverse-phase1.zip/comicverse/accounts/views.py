from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render

from comics.models import Bookmark, Comic

from .forms import ProfileForm, RegisterForm, UserUpdateForm


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Welcome to ComicVerse! Your account is ready.")
        return redirect("dashboard")
    return render(request, "accounts/register.html", {"form": form})


def profile(request, username):
    creator = get_object_or_404(User.objects.select_related("profile"), username=username)
    is_owner = request.user == creator
    comics = creator.comics.all()
    published = comics.filter(status=Comic.PUBLISHED)
    context = {
        "creator": creator,
        "is_owner": is_owner,
        "published": published,
        "drafts": comics.filter(status=Comic.DRAFT) if is_owner else [],
        "bookmarks": (
            Comic.objects.filter(bookmarks__user=creator, status=Comic.PUBLISHED)
            if is_owner else []
        ),
        "recent_activity": (
            Bookmark.objects.filter(user=creator).select_related("comic")[:5] if is_owner else []
        ),
    }
    return render(request, "accounts/profile.html", context)


@login_required
def profile_edit(request):
    user_form = UserUpdateForm(request.POST or None, instance=request.user)
    profile_form = ProfileForm(request.POST or None, request.FILES or None, instance=request.user.profile)
    if request.method == "POST" and user_form.is_valid() and profile_form.is_valid():
        user_form.save()
        profile_form.save()
        messages.success(request, "Profile updated.")
        return redirect("profile", username=request.user.username)
    return render(request, "accounts/profile_edit.html", {"user_form": user_form, "profile_form": profile_form})
