// Add Bootstrap form styling to Django-rendered inputs
document.querySelectorAll("input:not([type=checkbox]):not([type=hidden]):not([type=file]), textarea, select")
  .forEach((el) => el.classList.add(el.tagName === "SELECT" ? "form-select" : "form-control"));
document.querySelectorAll("input[type=file]").forEach((el) => el.classList.add("form-control"));

// Reveal-on-scroll animation
const io = new IntersectionObserver((entries) => {
  entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
}, { threshold: 0.1 });
document.querySelectorAll(".section, .comic-card, .step-card, .stat").forEach((el) => {
  el.classList.add("reveal"); io.observe(el);
});
